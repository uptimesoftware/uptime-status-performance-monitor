Status - Performance Plug-In Monitor:

This plugin monitors the performance status for the data collector, including:

- Number of data samples in the last 5 minutes
- Number of data samples in the last hour
- Number of data samples in the last day
- Daily target of data samples
