#!/usr/bin/perl

use LWP::UserAgent;

my $hostname = shift || $ENV{UPTIME_HOSTNAME};
my $ua = LWP::UserAgent->new;
my $url = 'http://' . $hostname . ':9996/status/performance';
my $res = $ua->get($url);

open(MYOUTFILE, ">performance.txt");
print MYOUTFILE $res->content;
close(MYOUTFILE);

open(MYOUTFILE, "<performance.txt");
while (<MYOUTFILE>)
{
	my ($line) = $_;
	if ( /.*(\<samples_in_last_five_minutes\>)([0-9]+)(\<\/samples_in_last_five_minutes\>)/ )
	{
		$samplemin=$2;
	}
	elsif ( /.*(\<samples_in_last_hour\>)([0-9]+)(\<\/samples_in_last_hour\>)/ )
	{
		$samplehour=$2;
	}
	elsif ( /.*(\<samples_in_last_day\>)([0-9]+)(\<\/samples_in_last_day\>)/ )
	{
		$sampleday=$2;
	}
	elsif ( /.*(\<daily_target\>)([0-9]+)(\<\/daily_target\>)/ )
	{
		$target=$2;
	}
}
close(MYOUTFILE);
print "samplemin $samplemin\n";
print "samplehour $samplehour\n";
print "sampleday $sampleday\n";
print "target $target\n";
exit 0;
